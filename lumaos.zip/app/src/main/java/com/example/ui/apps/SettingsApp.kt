package com.example.ui.apps

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.viewmodel.LumaOSViewModel

@Composable
fun SettingsApp(
    viewModel: LumaOSViewModel,
    modifier: Modifier = Modifier
) {
    val themeMode by viewModel.themeMode.collectAsState()
    val wallpaperMode by viewModel.wallpaperMode.collectAsState()
    val wifiEnabled by viewModel.wifiEnabled.collectAsState()
    val bluetoothEnabled by viewModel.bluetoothEnabled.collectAsState()
    val isLocked by viewModel.isLocked.collectAsState()

    var showCleanToast by remember { mutableStateOf(false) }

    Surface(
        modifier = modifier
            .fillMaxSize()
            .testTag("app_settings"),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Top Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(onClick = { viewModel.closeCurrentApp() }) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                }
                Text("LumaOS System Settings", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(16.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.weight(1f)
            ) {
                // Section 1: Appearance & Display
                item {
                    Text("APPEARANCE & THEME", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("Theme Engine Mode", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(
                                    selected = themeMode == "DARK",
                                    onClick = { viewModel.setThemeMode("DARK") },
                                    label = { Text("Cyber Dark") }
                                )
                                FilterChip(
                                    selected = themeMode == "NEON",
                                    onClick = { viewModel.setThemeMode("NEON") },
                                    label = { Text("Neon Matrix") }
                                )
                                FilterChip(
                                    selected = themeMode == "LIGHT",
                                    onClick = { viewModel.setThemeMode("LIGHT") },
                                    label = { Text("Glass Light") }
                                )
                            }

                            Divider(modifier = Modifier.padding(vertical = 12.dp))

                            Text("Wallpaper Background", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(
                                    selected = wallpaperMode == "DARK",
                                    onClick = { viewModel.setWallpaperMode("DARK") },
                                    label = { Text("Cyber Wave Wallpaper") }
                                )
                                FilterChip(
                                    selected = wallpaperMode == "LIGHT",
                                    onClick = { viewModel.setWallpaperMode("LIGHT") },
                                    label = { Text("Ambient Glow Wallpaper") }
                                )
                            }
                        }
                    }
                }

                // Section 2: Connectivity & Power
                item {
                    Text("NETWORK & HARDWARE", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            ListItem(
                                headlineContent = { Text("Wi-Fi Network") },
                                supportingContent = { Text(if (wifiEnabled) "Connected to LumaNet 5G" else "Disconnected") },
                                leadingContent = { Icon(Icons.Default.Wifi, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                                trailingContent = {
                                    Switch(checked = wifiEnabled, onCheckedChange = { viewModel.toggleWifi() })
                                }
                            )
                            Divider()
                            ListItem(
                                headlineContent = { Text("Bluetooth 5.3") },
                                supportingContent = { Text(if (bluetoothEnabled) "Searching for accessories..." else "Off") },
                                leadingContent = { Icon(Icons.Default.Bluetooth, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                                trailingContent = {
                                    Switch(checked = bluetoothEnabled, onCheckedChange = { viewModel.toggleBluetooth() })
                                }
                            )
                        }
                    }
                }

                // Section 3: Maintenance & Cache
                item {
                    Text("STORAGE & MAINTENANCE", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Button(
                                onClick = { showCleanToast = true },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.CleaningServices, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Optimize RAM & Clean Cache")
                            }

                            if (showCleanToast) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("Cleaned 420 MB temporary cache files!", fontSize = 12.sp, color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // Section 4: About OS
                item {
                    Text("ABOUT LUMAOS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("LumaOS v2.5 Cyber Edition", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                            Text("Kernel: Linux CyberKernel 6.1-aarch64", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Build: Jetpack Compose + Room Database Engine", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Default Lock PIN: 1234", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        }
    }
}
