package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        LumaNoteEntity::class,
        LumaFileEntity::class,
        LumaSettingEntity::class,
        LumaNotificationEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class LumaDatabase : RoomDatabase() {
    abstract fun noteDao(): LumaNoteDao
    abstract fun fileDao(): LumaFileDao
    abstract fun settingDao(): LumaSettingDao
    abstract fun notificationDao(): LumaNotificationDao

    companion object {
        @Volatile
        private var INSTANCE: LumaDatabase? = null

        fun getDatabase(context: Context): LumaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    LumaDatabase::class.java,
                    "luma_os_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
