package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "luma_notes")
data class LumaNoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val content: String,
    val category: String = "General",
    val timestamp: Long = System.currentTimeMillis(),
    val isPinned: Boolean = false
)

@Entity(tableName = "luma_files")
data class LumaFileEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val fileName: String,
    val fileType: String = "TXT",
    val content: String = "",
    val sizeKb: Int = 1,
    val path: String = "/system/user/",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "luma_settings")
data class LumaSettingEntity(
    @PrimaryKey val key: String,
    val value: String
)

@Entity(tableName = "luma_notifications")
data class LumaNotificationEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val message: String,
    val appName: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)
