package com.example.ui.apps

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.viewmodel.LumaOSViewModel
import kotlinx.coroutines.launch

data class TerminalLine(val text: String, val isCommand: Boolean = false)

@Composable
fun TerminalApp(
    viewModel: LumaOSViewModel,
    modifier: Modifier = Modifier
) {
    var commandInput by remember { mutableStateOf("") }
    val history = remember {
        mutableStateListOf(
            TerminalLine("LumaOS Terminal v2.5 [Kernel Cyber-6.1]"),
            TerminalLine("Type 'help' to view available system commands."),
            TerminalLine("--------------------------------------------")
        )
    }

    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    val cpuUsage by viewModel.cpuUsage.collectAsState()
    val ramUsage by viewModel.ramUsage.collectAsState()
    val batteryLevel by viewModel.batteryLevel.collectAsState()
    val notes by viewModel.notes.collectAsState()
    val files by viewModel.files.collectAsState()

    fun executeCommand(cmd: String) {
        val trimmed = cmd.trim()
        if (trimmed.isEmpty()) return

        history.add(TerminalLine("luma@sys:~$ $trimmed", isCommand = true))

        val parts = trimmed.split(" ")
        when (parts[0].lowercase()) {
            "help" -> {
                history.add(TerminalLine("Available Commands:"))
                history.add(TerminalLine("  help               - Show list of terminal commands"))
                history.add(TerminalLine("  sysinfo            - Display CPU, RAM & Battery stats"))
                history.add(TerminalLine("  theme <dark|neon|light> - Change OS theme palette"))
                history.add(TerminalLine("  notes              - List all persistent notes in database"))
                history.add(TerminalLine("  files              - List all files in storage"))
                history.add(TerminalLine("  apps               - Open Luma App Drawer"))
                history.add(TerminalLine("  ping               - Test system responsiveness"))
                history.add(TerminalLine("  battery            - Show battery percentage"))
                history.add(TerminalLine("  clear              - Clear terminal history"))
                history.add(TerminalLine("  echo <message>     - Print message to screen"))
            }
            "sysinfo" -> {
                history.add(TerminalLine("OS: LumaOS Cyber v2.5"))
                history.add(TerminalLine("Architecture: aarch64 (Android JVM)"))
                history.add(TerminalLine("CPU Usage: $cpuUsage%"))
                history.add(TerminalLine("RAM Usage: $ramUsage% / 8.0 GB"))
                history.add(TerminalLine("Battery Level: $batteryLevel%"))
            }
            "theme" -> {
                if (parts.size > 1) {
                    val mode = parts[1].uppercase()
                    if (mode in listOf("DARK", "NEON", "LIGHT")) {
                        viewModel.setThemeMode(mode)
                        history.add(TerminalLine("System theme switched to $mode"))
                    } else {
                        history.add(TerminalLine("Invalid theme mode. Use: dark, neon, light"))
                    }
                } else {
                    history.add(TerminalLine("Usage: theme <dark|neon|light>"))
                }
            }
            "notes" -> {
                history.add(TerminalLine("=== Luma Database Notes (${notes.size}) ==="))
                notes.forEach { n ->
                    history.add(TerminalLine("[${n.id}] ${n.title} - ${n.category}"))
                }
            }
            "files" -> {
                history.add(TerminalLine("=== Storage Files (${files.size}) ==="))
                files.forEach { f ->
                    history.add(TerminalLine("${f.fileName} (${f.sizeKb} KB) [${f.fileType}]"))
                }
            }
            "apps" -> {
                viewModel.toggleAppDrawer()
                history.add(TerminalLine("Opening Luma App Drawer..."))
            }
            "ping" -> {
                history.add(TerminalLine("64 bytes from 127.0.0.1: icmp_seq=1 ttl=64 time=0.8ms"))
                history.add(TerminalLine("64 bytes from 127.0.0.1: icmp_seq=2 ttl=64 time=0.6ms"))
            }
            "battery" -> {
                history.add(TerminalLine("Battery Status: $batteryLevel% [Healthy]"))
            }
            "clear" -> {
                history.clear()
            }
            "echo" -> {
                history.add(TerminalLine(parts.drop(1).joinToString(" ")))
            }
            else -> {
                history.add(TerminalLine("Command not found: $trimmed. Type 'help' for commands."))
            }
        }

        commandInput = ""
        coroutineScope.launch {
            listState.animateScrollToItem(history.size - 1)
        }
    }

    Surface(
        modifier = modifier
            .fillMaxSize()
            .testTag("app_terminal"),
        color = Color(0xFF090D12)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
        ) {
            // Terminal Top Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconButton(onClick = { viewModel.closeCurrentApp() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = Color(0xFF00FF87))
                    }
                    Text(
                        text = "Luma Terminal Shell",
                        color = Color(0xFF00FF87),
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 16.sp
                    )
                }

                Surface(
                    color = Color(0xFF00FF87).copy(alpha = 0.2f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "ONLINE",
                        color = Color(0xFF00FF87),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Output History Area
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(history) { line ->
                    Text(
                        text = line.text,
                        color = if (line.isCommand) Color(0xFF00E5FF) else Color(0xFFD1D5DB),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        fontWeight = if (line.isCommand) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Input Command Field
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "$",
                    color = Color(0xFF00FF87),
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 18.sp
                )

                OutlinedTextField(
                    value = commandInput,
                    onValueChange = { commandInput = it },
                    placeholder = { Text("Enter command...", color = Color.Gray, fontSize = 12.sp) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { executeCommand(commandInput) }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFF00FF87),
                        unfocusedBorderColor = Color.DarkGray
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("terminal_input")
                )

                IconButton(
                    onClick = { executeCommand(commandInput) },
                    modifier = Modifier
                        .background(Color(0xFF00FF87), CircleShape)
                        .size(40.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Send",
                        tint = Color.Black,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}
