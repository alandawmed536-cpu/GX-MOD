package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.viewmodel.LumaOSViewModel

data class LumaAppItem(
    val key: String,
    val name: String,
    val category: String,
    val icon: ImageVector,
    val accentColor: Color
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LumaAppDrawer(
    viewModel: LumaOSViewModel,
    modifier: Modifier = Modifier
) {
    val isOpen by viewModel.isAppDrawerOpen.collectAsState()
    var searchQuery by remember { mutableStateOf("") }

    val allApps = listOf(
        LumaAppItem("TERMINAL", "Terminal", "System", Icons.Default.Terminal, MaterialTheme.colorScheme.primary),
        LumaAppItem("NOTES", "Luma Notes", "Productivity", Icons.Default.EditNote, MaterialTheme.colorScheme.secondary),
        LumaAppItem("FILES", "Files Manager", "Storage", Icons.Default.Folder, MaterialTheme.colorScheme.tertiary),
        LumaAppItem("AI_ASSISTANT", "Luma AI", "AI Intelligence", Icons.Default.Psychology, Color(0xFF00FF87)),
        LumaAppItem("SETTINGS", "Settings", "System", Icons.Default.Settings, Color(0xFF9333EA)),
        LumaAppItem("CALCULATOR", "Calculator", "Utilities", Icons.Default.Calculate, Color(0xFF0284C7)),
        LumaAppItem("SYSTEM_MONITOR", "Task Manager", "System", Icons.Default.Analytics, Color(0xFFE11D48)),
        LumaAppItem("CAMERA", "Camera", "Media", Icons.Default.PhotoCamera, Color(0xFFEA580C))
    )

    val filteredApps = allApps.filter {
        it.name.contains(searchQuery, ignoreCase = true) ||
                it.category.contains(searchQuery, ignoreCase = true)
    }

    AnimatedVisibility(
        visible = isOpen,
        enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
        exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
        modifier = modifier
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .testTag("luma_app_drawer"),
            color = MaterialTheme.colorScheme.background.copy(alpha = 0.98f)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .padding(20.dp)
            ) {
                // Top Search & Close Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Search apps & commands...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Close, contentDescription = "Clear")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("app_search_input")
                    )

                    IconButton(
                        onClick = { viewModel.toggleAppDrawer() },
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Icon(imageVector = Icons.Default.KeyboardArrowDown, contentDescription = "Close Drawer")
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Text(
                    text = "Luma System Applications (${filteredApps.size})",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Apps Grid
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalArrangement = Arrangement.spacedBy(20.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(filteredApps, key = { it.key }) { app ->
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .clickable { viewModel.openApp(app.key) }
                                .testTag("app_item_${app.key}")
                        ) {
                            Surface(
                                shape = RoundedCornerShape(22.dp),
                                color = app.accentColor.copy(alpha = 0.15f),
                                border = ButtonDefaults.outlinedButtonBorder.copy(
                                    brush = androidx.compose.ui.graphics.SolidColor(app.accentColor.copy(alpha = 0.4f))
                                ),
                                modifier = Modifier.size(62.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = app.icon,
                                        contentDescription = app.name,
                                        tint = app.accentColor,
                                        modifier = Modifier.size(32.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = app.name,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        }
                    }
                }
            }
        }
    }
}
