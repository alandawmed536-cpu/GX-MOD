package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.random.Random

class LumaOSViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: LumaRepository

    init {
        val database = LumaDatabase.getDatabase(application)
        repository = LumaRepository(database)
        seedInitialSystemData()
        startSystemMetricsTimer()
    }

    // Database flows
    val notes = repository.notes.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val files = repository.files.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val notifications = repository.notifications.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // UI System States
    private val _isLocked = MutableStateFlow(true)
    val isLocked: StateFlow<Boolean> = _isLocked.asStateFlow()

    private val _isNotificationShadeOpen = MutableStateFlow(false)
    val isNotificationShadeOpen: StateFlow<Boolean> = _isNotificationShadeOpen.asStateFlow()

    private val _isAppDrawerOpen = MutableStateFlow(false)
    val isAppDrawerOpen: StateFlow<Boolean> = _isAppDrawerOpen.asStateFlow()

    private val _currentApp = MutableStateFlow<String?>(null)
    val currentApp: StateFlow<String?> = _currentApp.asStateFlow()

    private val _activeBackgroundApps = MutableStateFlow<List<String>>(listOf("System Engine", "Luma Security"))
    val activeBackgroundApps: StateFlow<List<String>> = _activeBackgroundApps.asStateFlow()

    // Quick Settings
    private val _wifiEnabled = MutableStateFlow(true)
    val wifiEnabled: StateFlow<Boolean> = _wifiEnabled.asStateFlow()

    private val _bluetoothEnabled = MutableStateFlow(true)
    val bluetoothEnabled: StateFlow<Boolean> = _bluetoothEnabled.asStateFlow()

    private val _flashlightEnabled = MutableStateFlow(false)
    val flashlightEnabled: StateFlow<Boolean> = _flashlightEnabled.asStateFlow()

    private val _airplaneMode = MutableStateFlow(false)
    val airplaneMode: StateFlow<Boolean> = _airplaneMode.asStateFlow()

    private val _brightnessLevel = MutableStateFlow(0.85f)
    val brightnessLevel: StateFlow<Float> = _brightnessLevel.asStateFlow()

    private val _volumeLevel = MutableStateFlow(0.70f)
    val volumeLevel: StateFlow<Float> = _volumeLevel.asStateFlow()

    // Theme & Wallpaper
    private val _themeMode = MutableStateFlow("DARK") // "DARK", "LIGHT", "NEON"
    val themeMode: StateFlow<String> = _themeMode.asStateFlow()

    private val _wallpaperMode = MutableStateFlow("DARK") // "DARK", "LIGHT"
    val wallpaperMode: StateFlow<String> = _wallpaperMode.asStateFlow()

    // Realtime OS Metrics
    private val _cpuUsage = MutableStateFlow(24)
    val cpuUsage: StateFlow<Int> = _cpuUsage.asStateFlow()

    private val _ramUsage = MutableStateFlow(42)
    val ramUsage: StateFlow<Int> = _ramUsage.asStateFlow()

    private val _batteryLevel = MutableStateFlow(88)
    val batteryLevel: StateFlow<Int> = _batteryLevel.asStateFlow()

    // Security
    val lockPin = "1234"

    fun unlockSystem(pinInput: String): Boolean {
        return if (pinInput == lockPin || pinInput.isEmpty()) {
            _isLocked.value = false
            true
        } else {
            false
        }
    }

    fun lockSystem() {
        _isLocked.value = true
        _isNotificationShadeOpen.value = false
        _isAppDrawerOpen.value = false
    }

    fun openApp(appKey: String) {
        _currentApp.value = appKey
        _isAppDrawerOpen.value = false
        _isNotificationShadeOpen.value = false
        if (!_activeBackgroundApps.value.contains(appKey)) {
            _activeBackgroundApps.value = _activeBackgroundApps.value + appKey
        }
    }

    fun closeCurrentApp() {
        _currentApp.value = null
    }

    fun closeBackgroundApp(appKey: String) {
        _activeBackgroundApps.value = _activeBackgroundApps.value.filter { it != appKey }
        if (_currentApp.value == appKey) {
            _currentApp.value = null
        }
    }

    fun toggleNotificationShade() {
        _isNotificationShadeOpen.value = !_isNotificationShadeOpen.value
    }

    fun toggleAppDrawer() {
        _isAppDrawerOpen.value = !_isAppDrawerOpen.value
    }

    fun toggleWifi() {
        _wifiEnabled.value = !_wifiEnabled.value
    }

    fun toggleBluetooth() {
        _bluetoothEnabled.value = !_bluetoothEnabled.value
    }

    fun toggleFlashlight() {
        _flashlightEnabled.value = !_flashlightEnabled.value
    }

    fun toggleAirplaneMode() {
        _airplaneMode.value = !_airplaneMode.value
    }

    fun setBrightness(level: Float) {
        _brightnessLevel.value = level
    }

    fun setVolume(level: Float) {
        _volumeLevel.value = level
    }

    fun setThemeMode(mode: String) {
        _themeMode.value = mode
    }

    fun setWallpaperMode(mode: String) {
        _wallpaperMode.value = mode
    }

    // Database Actions
    fun addNote(title: String, content: String, category: String = "General") {
        viewModelScope.launch {
            repository.addNote(title, content, category)
        }
    }

    fun deleteNote(id: Int) {
        viewModelScope.launch {
            repository.deleteNote(id)
        }
    }

    fun addFile(fileName: String, fileType: String, content: String, sizeKb: Int = 2) {
        viewModelScope.launch {
            repository.addFile(fileName, fileType, content, sizeKb)
        }
    }

    fun deleteFile(id: Int) {
        viewModelScope.launch {
            repository.deleteFile(id)
        }
    }

    fun addNotification(title: String, message: String, appName: String) {
        viewModelScope.launch {
            repository.addNotification(title, message, appName)
        }
    }

    fun deleteNotification(id: Int) {
        viewModelScope.launch {
            repository.deleteNotification(id)
        }
    }

    fun clearAllNotifications() {
        viewModelScope.launch {
            repository.clearNotifications()
        }
    }

    private fun seedInitialSystemData() {
        viewModelScope.launch {
            // Seed initial note if empty
            if (notes.value.isEmpty()) {
                repository.addNote(
                    title = "Welcome to LumaOS",
                    content = "LumaOS is a futuristic, highly persistent Android OS experience built with Jetpack Compose. Try out Terminal, AI Assistant, Files, and System Monitor!",
                    category = "System"
                )
                repository.addNote(
                    title = "Terminal Commands",
                    content = "Type 'help', 'sysinfo', 'theme neon', 'notes', 'apps', 'clear' in the Luma Terminal app.",
                    category = "Code"
                )
            }

            if (files.value.isEmpty()) {
                repository.addFile("system_config.json", "JSON", "{\"os\":\"LumaOS v2.5\",\"kernel\":\"CyberKernel-6.1\",\"built_in_ai\":true}", 4)
                repository.addFile("kernel_log.txt", "LOG", "[12:00:00] LumaOS Kernel initialized successfully.\n[12:00:01] Room SQLite storage connected.", 12)
                repository.addFile("project_luma.txt", "TXT", "Project LumaOS: High performance Android OS environment with glassmorphic UI.", 2)
            }

            if (notifications.value.isEmpty()) {
                repository.addNotification("Luma Engine", "System initialized and running smoothly at 120 FPS.", "Luma System")
                repository.addNotification("Security Alert", "Luma Protection: Zero vulnerabilities detected.", "Luma Security")
            }
        }
    }

    private fun startSystemMetricsTimer() {
        viewModelScope.launch {
            while (true) {
                delay(3000)
                _cpuUsage.value = Random.nextInt(12, 45)
                _ramUsage.value = Random.nextInt(38, 62)
            }
        }
    }
}
