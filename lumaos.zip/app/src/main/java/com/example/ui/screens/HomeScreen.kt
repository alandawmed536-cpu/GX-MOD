package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.*
import com.example.viewmodel.LumaOSViewModel

@Composable
fun HomeScreen(
    viewModel: LumaOSViewModel,
    modifier: Modifier = Modifier
) {
    val wallpaperMode by viewModel.wallpaperMode.collectAsState()

    val quickApps = listOf(
        LumaAppItem("TERMINAL", "Terminal", "System", Icons.Default.Terminal, MaterialTheme.colorScheme.primary),
        LumaAppItem("NOTES", "Notes", "Productivity", Icons.Default.EditNote, MaterialTheme.colorScheme.secondary),
        LumaAppItem("FILES", "Files", "Storage", Icons.Default.Folder, MaterialTheme.colorScheme.tertiary),
        LumaAppItem("AI_ASSISTANT", "Luma AI", "AI", Icons.Default.Psychology, Color(0xFF00FF87)),
        LumaAppItem("CALCULATOR", "Calculator", "Utility", Icons.Default.Calculate, Color(0xFF0284C7)),
        LumaAppItem("SYSTEM_MONITOR", "Tasks", "System", Icons.Default.Analytics, Color(0xFFE11D48)),
        LumaAppItem("SETTINGS", "Settings", "System", Icons.Default.Settings, Color(0xFF9333EA)),
        LumaAppItem("CAMERA", "Camera", "Media", Icons.Default.PhotoCamera, Color(0xFFEA580C))
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("home_screen")
    ) {
        // Wallpaper Background with Fallback
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    if (wallpaperMode == "LIGHT") {
                        Brush.verticalGradient(
                            listOf(
                                Color(0xFF1E293B),
                                Color(0xFF0F172A),
                                Color(0xFF020617)
                            )
                        )
                    } else {
                        Brush.verticalGradient(
                            listOf(
                                Color(0xFF090D16),
                                Color(0xFF131B2A),
                                Color(0xFF070B12)
                            )
                        )
                    }
                )
        )

        val wallpaperRes = if (wallpaperMode == "LIGHT") {
            R.drawable.img_luma_wallpaper_light_1784919301624
        } else {
            R.drawable.img_luma_wallpaper_dark_1784919289778
        }

        Image(
            painter = painterResource(id = wallpaperRes),
            contentDescription = "Luma Wallpaper",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        // Gradient overlay for legibility
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Black.copy(alpha = 0.35f),
                            Color.Transparent,
                            Color.Black.copy(alpha = 0.5f)
                        )
                    )
                )
        )

        // Desktop Layout Content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 48.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Clock & Weather Glass Widgets
                LumaClockWidget()

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    LumaWeatherWidget(modifier = Modifier.weight(1f))
                }

                // AI Quick Search Bar
                LumaAIQuickSearchBar(onClick = { viewModel.openApp("AI_ASSISTANT") })

                // System Health Live Card
                LumaSystemMonitorWidget(
                    viewModel = viewModel,
                    onClick = { viewModel.openApp("SYSTEM_MONITOR") }
                )
            }

            // Desktop App Icon Grid
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.45f)
                ),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Luma Launchpad",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )

                        TextButton(
                            onClick = { viewModel.toggleAppDrawer() },
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text("All Apps", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    LazyVerticalGrid(
                        columns = GridCells.Fixed(4),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.height(140.dp)
                    ) {
                        items(quickApps) { app ->
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .clickable { viewModel.openApp(app.key) }
                                    .testTag("home_app_${app.key}")
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(18.dp),
                                    color = app.accentColor.copy(alpha = 0.2f),
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = app.icon,
                                            contentDescription = app.name,
                                            tint = app.accentColor,
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = app.name,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
