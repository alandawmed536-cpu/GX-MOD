package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface LumaNoteDao {
    @Query("SELECT * FROM luma_notes ORDER BY isPinned DESC, timestamp DESC")
    fun getAllNotes(): Flow<List<LumaNoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: LumaNoteEntity): Long

    @Update
    suspend fun updateNote(note: LumaNoteEntity)

    @Query("DELETE FROM luma_notes WHERE id = :id")
    suspend fun deleteNoteById(id: Int)
}

@Dao
interface LumaFileDao {
    @Query("SELECT * FROM luma_files ORDER BY createdAt DESC")
    fun getAllFiles(): Flow<List<LumaFileEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFile(file: LumaFileEntity): Long

    @Query("DELETE FROM luma_files WHERE id = :id")
    suspend fun deleteFileById(id: Int)
}

@Dao
interface LumaSettingDao {
    @Query("SELECT * FROM luma_settings")
    fun getAllSettings(): Flow<List<LumaSettingEntity>>

    @Query("SELECT * FROM luma_settings WHERE key = :key LIMIT 1")
    suspend fun getSetting(key: String): LumaSettingEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setSetting(setting: LumaSettingEntity)
}

@Dao
interface LumaNotificationDao {
    @Query("SELECT * FROM luma_notifications ORDER BY timestamp DESC")
    fun getAllNotifications(): Flow<List<LumaNotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: LumaNotificationEntity)

    @Query("DELETE FROM luma_notifications WHERE id = :id")
    suspend fun deleteNotificationById(id: Int)

    @Query("DELETE FROM luma_notifications")
    suspend fun clearAllNotifications()
}
