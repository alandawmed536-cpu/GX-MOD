package com.example.ui.apps

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.viewmodel.LumaOSViewModel

@Composable
fun CameraSimulatorApp(
    viewModel: LumaOSViewModel,
    modifier: Modifier = Modifier
) {
    var capturedToast by remember { mutableStateOf(false) }
    var mode by remember { mutableStateOf("PHOTO") }

    Surface(
        modifier = modifier
            .fillMaxSize()
            .testTag("app_camera"),
        color = Color.Black
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Camera Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { viewModel.closeCurrentApp() }) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Icon(Icons.Default.FlashOn, contentDescription = "Flash", tint = Color.White)
                    Icon(Icons.Default.HdrOn, contentDescription = "HDR", tint = Color.White)
                    Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.White)
                }
            }

            // Viewfinder Simulated Preview
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(vertical = 16.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xFF1E293B), Color(0xFF0F172A))
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Camera,
                        contentDescription = null,
                        tint = Color.Cyan.copy(alpha = 0.5f),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Luma HD Viewfinder Active (4K @ 60FPS)",
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    if (capturedToast) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Surface(
                            color = Color.Cyan,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "Photo Captured & Saved to Files!",
                                color = Color.Black,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }

            // Camera Shutter Controls
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilterChip(
                        selected = mode == "PHOTO",
                        onClick = { mode = "PHOTO" },
                        label = { Text("PHOTO") },
                        colors = FilterChipDefaults.filterChipColors(labelColor = Color.White)
                    )
                    FilterChip(
                        selected = mode == "VIDEO",
                        onClick = { mode = "VIDEO" },
                        label = { Text("VIDEO") },
                        colors = FilterChipDefaults.filterChipColors(labelColor = Color.White)
                    )
                    FilterChip(
                        selected = mode == "PRO",
                        onClick = { mode = "PRO" },
                        label = { Text("PRO") },
                        colors = FilterChipDefaults.filterChipColors(labelColor = Color.White)
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = {}) {
                        Icon(Icons.Default.PhotoLibrary, contentDescription = "Gallery", tint = Color.White, modifier = Modifier.size(28.dp))
                    }

                    // Main Shutter Button
                    Surface(
                        onClick = {
                            capturedToast = true
                            viewModel.addFile("IMG_${System.currentTimeMillis()}.jpg", "IMG", "Luma Photo Capture Sample", 320)
                            viewModel.addNotification("Camera", "New high-resolution photo saved to files.", "Camera")
                        },
                        shape = CircleShape,
                        color = Color.White,
                        border = ButtonDefaults.outlinedButtonBorder.copy(
                            brush = SolidColor(Color.Cyan)
                        ),
                        modifier = Modifier
                            .size(72.dp)
                            .testTag("camera_shutter_button")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Box(
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(CircleShape)
                                    .background(Color.White)
                            )
                        }
                    }

                    IconButton(onClick = {}) {
                        Icon(Icons.Default.Cameraswitch, contentDescription = "Flip", tint = Color.White, modifier = Modifier.size(28.dp))
                    }
                }
            }
        }
    }
}
