package com.example.ui.apps

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.viewmodel.LumaOSViewModel
import kotlinx.coroutines.launch

data class AIChatMessage(
    val id: Int,
    val sender: String, // "USER" or "LUMA_AI"
    val message: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Composable
fun AIAssistantApp(
    viewModel: LumaOSViewModel,
    modifier: Modifier = Modifier
) {
    var promptInput by remember { mutableStateOf("") }
    val messages = remember {
        mutableStateListOf(
            AIChatMessage(
                id = 1,
                sender = "LUMA_AI",
                message = "Hello! I am Luma AI, your embedded OS intelligence. I can help you manage notes, control settings, check system health, or answer any question."
            )
        )
    }

    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    val cpuUsage by viewModel.cpuUsage.collectAsState()
    val ramUsage by viewModel.ramUsage.collectAsState()
    val batteryLevel by viewModel.batteryLevel.collectAsState()

    fun handleSendPrompt(prompt: String) {
        val trimmed = prompt.trim()
        if (trimmed.isEmpty()) return

        messages.add(AIChatMessage(id = messages.size + 1, sender = "USER", message = trimmed))
        promptInput = ""

        // Process response locally & control OS
        val lower = trimmed.lowercase()
        val aiResponse = when {
            lower.contains("theme") -> {
                if (lower.contains("neon")) {
                    viewModel.setThemeMode("NEON")
                    "I've updated your LumaOS theme to Neon Matrix!"
                } else if (lower.contains("light")) {
                    viewModel.setThemeMode("LIGHT")
                    "I've switched your LumaOS theme to Glass Light!"
                } else {
                    viewModel.setThemeMode("DARK")
                    "I've switched your LumaOS theme to Cyber Dark!"
                }
            }
            lower.contains("status") || lower.contains("health") || lower.contains("cpu") || lower.contains("ram") -> {
                "LumaOS Health Status: CPU is at $cpuUsage%, RAM at $ramUsage%, Battery level at $batteryLevel%. All systems operating optimally."
            }
            lower.contains("note") -> {
                viewModel.addNote("AI Note", trimmed, "AI")
                "I have automatically saved a new note in Luma Notes database!"
            }
            lower.contains("terminal") -> {
                viewModel.openApp("TERMINAL")
                "Opening Luma Terminal..."
            }
            lower.contains("hello") || lower.contains("hi") -> {
                "Greetings! How can I assist you with LumaOS today?"
            }
            else -> {
                "I analyzed '$trimmed'. LumaOS is fully operational. Try asking me to change theme to neon, check system status, or create a note!"
            }
        }

        messages.add(AIChatMessage(id = messages.size + 1, sender = "LUMA_AI", message = aiResponse))

        coroutineScope.launch {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Surface(
        modifier = modifier
            .fillMaxSize()
            .testTag("app_ai_assistant"),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconButton(onClick = { viewModel.closeCurrentApp() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                    Text("Luma AI Assistant", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }

                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Quick Prompt Suggestions
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                SuggestionChip(
                    onClick = { handleSendPrompt("Switch theme to neon") },
                    label = { Text("Neon Theme", fontSize = 11.sp) }
                )
                SuggestionChip(
                    onClick = { handleSendPrompt("Check system status") },
                    label = { Text("System Health", fontSize = 11.sp) }
                )
                SuggestionChip(
                    onClick = { handleSendPrompt("Open terminal") },
                    label = { Text("Terminal", fontSize = 11.sp) }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Chat Messages List
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages, key = { it.id }) { msg ->
                    val isUser = msg.sender == "USER"
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                    ) {
                        Surface(
                            color = if (isUser) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.widthIn(max = 280.dp)
                        ) {
                            Text(
                                text = msg.message,
                                fontSize = 13.sp,
                                color = if (isUser) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Prompt Input Field
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = promptInput,
                    onValueChange = { promptInput = it },
                    placeholder = { Text("Ask Luma AI...") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { handleSendPrompt(promptInput) }),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("ai_prompt_input")
                )

                IconButton(
                    onClick = { handleSendPrompt(promptInput) },
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary)
                        .size(46.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Send",
                        tint = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}
