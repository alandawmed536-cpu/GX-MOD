package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.viewmodel.LumaOSViewModel

@Composable
fun LumaNavigationDock(
    viewModel: LumaOSViewModel,
    modifier: Modifier = Modifier
) {
    val currentApp by viewModel.currentApp.collectAsState()

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .testTag("luma_navigation_dock"),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
        shape = RoundedCornerShape(24.dp),
        tonalElevation = 6.dp
    ) {
        Column(
            modifier = Modifier.padding(vertical = 6.dp, horizontal = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // App Quick Launch Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                DockIcon(
                    title = "Terminal",
                    icon = Icons.Default.Terminal,
                    isActive = currentApp == "TERMINAL",
                    onClick = { viewModel.openApp("TERMINAL") }
                )
                DockIcon(
                    title = "Notes",
                    icon = Icons.Default.EditNote,
                    isActive = currentApp == "NOTES",
                    onClick = { viewModel.openApp("NOTES") }
                )

                // Central App Drawer Launcher Button
                Surface(
                    onClick = { viewModel.toggleAppDrawer() },
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("app_drawer_button")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Apps,
                            contentDescription = "App Drawer",
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }

                DockIcon(
                    title = "Files",
                    icon = Icons.Default.Folder,
                    isActive = currentApp == "FILES",
                    onClick = { viewModel.openApp("FILES") }
                )
                DockIcon(
                    title = "AI Chat",
                    icon = Icons.Default.Psychology,
                    isActive = currentApp == "AI_ASSISTANT",
                    onClick = { viewModel.openApp("AI_ASSISTANT") }
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Bottom Navigation Pill / Gesture Home Indicator
            Box(
                modifier = Modifier
                    .width(100.dp)
                    .height(5.dp)
                    .clip(CircleShape)
                    .background(
                        if (currentApp != null) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                    )
                    .clickable { viewModel.closeCurrentApp() }
                    .testTag("home_gesture_bar")
            )
        }
    }
}

@Composable
fun DockIcon(
    title: String,
    icon: ImageVector,
    isActive: Boolean,
    onClick: () -> Unit
) {
    val bgColor = if (isActive) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
    val tintColor = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface

    Surface(
        onClick = onClick,
        shape = CircleShape,
        color = bgColor,
        modifier = Modifier.size(40.dp)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = tintColor,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}
