package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// LumaOS Futuristic Theme Colors
val LumaCyberBackground = Color(0xFF090D16)
val LumaCyberSurface = Color(0xFF131B2A)
val LumaCyberSurfaceVariant = Color(0xFF1D283A)
val LumaCyberPrimary = Color(0xFF00E5FF)
val LumaCyberSecondary = Color(0xFF7000FF)
val LumaCyberAccent = Color(0xFF00FF87)
val LumaCyberOnBackground = Color(0xFFE2E8F0)

// LumaOS Light Theme Colors
val LumaLightBackground = Color(0xFFF1F5F9)
val LumaLightSurface = Color(0xFFFFFFFF)
val LumaLightPrimary = Color(0xFF0066FF)
val LumaLightSecondary = Color(0xFF5B21B6)
val LumaLightAccent = Color(0xFF10B981)

// LumaOS Neon Matrix Colors
val LumaNeonBackground = Color(0xFF050B08)
val LumaNeonSurface = Color(0xFF0A1912)
val LumaNeonPrimary = Color(0xFF00FF66)
val LumaNeonSecondary = Color(0xFF00D8FF)
val LumaNeonAccent = Color(0xFFFF007A)
