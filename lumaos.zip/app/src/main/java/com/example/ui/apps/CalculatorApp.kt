package com.example.ui.apps

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.viewmodel.LumaOSViewModel

@Composable
fun CalculatorApp(
    viewModel: LumaOSViewModel,
    modifier: Modifier = Modifier
) {
    var display by remember { mutableStateOf("0") }
    var expression by remember { mutableStateOf("") }

    val buttons = listOf(
        "C", "DEL", "%", "/",
        "7", "8", "9", "*",
        "4", "5", "6", "-",
        "1", "2", "3", "+",
        "00", "0", ".", "="
    )

    fun onButtonClick(btn: String) {
        when (btn) {
            "C" -> {
                display = "0"
                expression = ""
            }
            "DEL" -> {
                if (display.length > 1) {
                    display = display.dropLast(1)
                } else {
                    display = "0"
                }
            }
            "=" -> {
                try {
                    val result = evaluateSimpleExpression(display)
                    expression = display + " ="
                    display = result
                } catch (e: Exception) {
                    display = "Error"
                }
            }
            "+", "-", "*", "/", "%" -> {
                if (display != "Error") {
                    display += " $btn "
                }
            }
            else -> {
                if (display == "0" || display == "Error") {
                    display = btn
                } else {
                    display += btn
                }
            }
        }
    }

    Surface(
        modifier = modifier
            .fillMaxSize()
            .testTag("app_calculator"),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { viewModel.closeCurrentApp() }) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text("Luma Cyber Calculator", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Display Screen
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.Bottom
                ) {
                    Text(
                        text = expression,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = display,
                        fontSize = 36.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Keypad
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(buttons) { btn ->
                    val isOp = btn in listOf("/", "*", "-", "+", "=", "%")
                    val isAction = btn in listOf("C", "DEL")

                    Surface(
                        onClick = { onButtonClick(btn) },
                        shape = CircleShape,
                        color = when {
                            btn == "=" -> MaterialTheme.colorScheme.primary
                            isOp -> MaterialTheme.colorScheme.secondaryContainer
                            isAction -> MaterialTheme.colorScheme.errorContainer
                            else -> MaterialTheme.colorScheme.surface
                        },
                        modifier = Modifier
                            .aspectRatio(1f)
                            .testTag("calc_btn_$btn")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = btn,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = when {
                                    btn == "=" -> MaterialTheme.colorScheme.onPrimary
                                    isOp -> MaterialTheme.colorScheme.onSecondaryContainer
                                    isAction -> MaterialTheme.colorScheme.onErrorContainer
                                    else -> MaterialTheme.colorScheme.onSurface
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

fun evaluateSimpleExpression(expr: String): String {
    val tokens = expr.trim().split(" ")
    if (tokens.isEmpty()) return "0"
    if (tokens.size == 1) return tokens[0]

    var result = tokens[0].toDoubleOrNull() ?: 0.0
    var i = 1
    while (i < tokens.size - 1) {
        val op = tokens[i]
        val nextVal = tokens[i + 1].toDoubleOrNull() ?: 0.0
        when (op) {
            "+" -> result += nextVal
            "-" -> result -= nextVal
            "*" -> result *= nextVal
            "/" -> if (nextVal != 0.0) result /= nextVal
            "%" -> result %= nextVal
        }
        i += 2
    }

    return if (result % 1.0 == 0.0) {
        result.toLong().toString()
    } else {
        String.format("%.2f", result)
    }
}
