package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.apps.*
import com.example.ui.components.*
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LockScreen
import com.example.ui.theme.LumaTheme
import com.example.viewmodel.LumaOSViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: LumaOSViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val themeMode by viewModel.themeMode.collectAsState()
            val isLocked by viewModel.isLocked.collectAsState()
            val currentApp by viewModel.currentApp.collectAsState()

            LumaTheme(themeMode = themeMode) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    if (isLocked) {
                        LockScreen(viewModel = viewModel)
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .testTag("luma_os_root")
                        ) {
                            // Main Desktop / Screen Area
                            HomeScreen(viewModel = viewModel)

                            // Currently Launched Application Overlay
                            currentApp?.let { appKey ->
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .statusBarsPadding()
                                        .padding(bottom = 70.dp)
                                ) {
                                    when (appKey) {
                                        "TERMINAL" -> TerminalApp(viewModel = viewModel)
                                        "NOTES" -> NotesApp(viewModel = viewModel)
                                        "FILES" -> FilesApp(viewModel = viewModel)
                                        "SETTINGS" -> SettingsApp(viewModel = viewModel)
                                        "AI_ASSISTANT" -> AIAssistantApp(viewModel = viewModel)
                                        "CALCULATOR" -> CalculatorApp(viewModel = viewModel)
                                        "SYSTEM_MONITOR" -> SystemMonitorApp(viewModel = viewModel)
                                        "CAMERA" -> CameraSimulatorApp(viewModel = viewModel)
                                    }
                                }
                            }

                            // Persistent Status Bar on Top
                            LumaStatusBar(
                                viewModel = viewModel,
                                modifier = Modifier.align(androidx.compose.ui.Alignment.TopCenter)
                            )

                            // Persistent Bottom Navigation Dock
                            LumaNavigationDock(
                                viewModel = viewModel,
                                modifier = Modifier.align(androidx.compose.ui.Alignment.BottomCenter)
                            )

                            // Notification Control Center Overlay
                            LumaNotificationShade(viewModel = viewModel)

                            // Luma App Drawer Overlay
                            LumaAppDrawer(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }
}
