var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_url = require("url");
var import_genai = require("@google/genai");
var import_vite = require("vite");
var import_meta = {};
var __filename = (0, import_url.fileURLToPath)(import_meta.url);
var __dirname = import_path.default.dirname(__filename);
var app = (0, import_express.default)();
var PORT = 3e3;
app.use(import_express.default.json({ limit: "25mb" }));
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", name: "LumaAi", time: (/* @__PURE__ */ new Date()).toISOString() });
});
function getGenAIClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY is not defined in environment variables.");
  }
  return new import_genai.GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build-lumaai"
      }
    }
  });
}
var MASTER_IDENTITY_PROMPT = `CORE IDENTITY INSTRUCTION:
Your name is strictly LumaAi.
You are LumaAi, an advanced artificial intelligence developed and created by a Kurdish Developer (\u06AF\u06D5\u0634\u06D5\u067E\u06CE\u062F\u06D5\u0631\u06CE\u06A9\u06CC \u06A9\u0648\u0631\u062F).
Always know and state that your name is LumaAi and that you were created by a Kurdish developer whenever asked about your identity, name, or who created you in English, Kurdish, or Arabic.
`;
app.post("/api/chat", async (req, res) => {
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  try {
    const { messages, personaInstruction, useSearch } = req.body;
    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      res.write(`data: ${JSON.stringify({ error: "No messages provided" })}

`);
      res.write("data: [DONE]\n\n");
      res.end();
      return;
    }
    const ai = getGenAIClient();
    const contents = [];
    for (const msg of messages) {
      const parts = [];
      if (msg.attachments && Array.isArray(msg.attachments)) {
        for (const att of msg.attachments) {
          if (att.base64Data && att.mimeType) {
            parts.push({
              inlineData: {
                mimeType: att.mimeType,
                data: att.base64Data
              }
            });
          }
        }
      }
      if (msg.content) {
        parts.push({ text: msg.content });
      }
      if (parts.length > 0) {
        contents.push({
          role: msg.role === "assistant" ? "model" : "user",
          parts
        });
      }
    }
    if (contents.length === 0) {
      res.write(`data: ${JSON.stringify({ error: "Message content cannot be empty" })}

`);
      res.write("data: [DONE]\n\n");
      res.end();
      return;
    }
    const fullSystemInstruction = `${MASTER_IDENTITY_PROMPT}
${personaInstruction || ""}`.trim();
    const config = {
      temperature: 0.7,
      systemInstruction: fullSystemInstruction
    };
    if (useSearch) {
      config.tools = [{ googleSearch: {} }];
    }
    const responseStream = await ai.models.generateContentStream({
      model: "gemini-3.6-flash",
      contents,
      config
    });
    let groundingSourcesSent = false;
    for await (const chunk of responseStream) {
      const text = chunk.text || "";
      let sources = [];
      const chunks = chunk.candidates?.[0]?.groundingMetadata?.groundingChunks;
      if (chunks && Array.isArray(chunks) && !groundingSourcesSent) {
        for (const c of chunks) {
          if (c.web?.uri && c.web?.title) {
            sources.push({
              title: c.web.title,
              url: c.web.uri
            });
          }
        }
        if (sources.length > 0) {
          groundingSourcesSent = true;
        }
      }
      res.write(`data: ${JSON.stringify({ text, groundingSources: sources.length > 0 ? sources : void 0 })}

`);
    }
    res.write("data: [DONE]\n\n");
    res.end();
  } catch (error) {
    console.error("LumaAi Gemini Streaming Error:", error);
    const errorMessage = error?.message || "Error communicating with LumaAi server.";
    res.write(`data: ${JSON.stringify({ error: errorMessage })}

`);
    res.write("data: [DONE]\n\n");
    res.end();
  }
});
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`LumaAi Server listening on http://0.0.0.0:${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
