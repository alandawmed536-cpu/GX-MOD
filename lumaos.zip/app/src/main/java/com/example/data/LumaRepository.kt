package com.example.data

import kotlinx.coroutines.flow.Flow

class LumaRepository(private val db: LumaDatabase) {

    // Notes
    val notes: Flow<List<LumaNoteEntity>> = db.noteDao().getAllNotes()
    suspend fun addNote(title: String, content: String, category: String = "General") {
        db.noteDao().insertNote(LumaNoteEntity(title = title, content = content, category = category))
    }
    suspend fun deleteNote(id: Int) {
        db.noteDao().deleteNoteById(id)
    }

    // Files
    val files: Flow<List<LumaFileEntity>> = db.fileDao().getAllFiles()
    suspend fun addFile(fileName: String, fileType: String, content: String, sizeKb: Int = 2) {
        db.fileDao().insertFile(
            LumaFileEntity(
                fileName = fileName,
                fileType = fileType,
                content = content,
                sizeKb = sizeKb
            )
        )
    }
    suspend fun deleteFile(id: Int) {
        db.fileDao().deleteFileById(id)
    }

    // Settings
    val settings: Flow<List<LumaSettingEntity>> = db.settingDao().getAllSettings()
    suspend fun setSetting(key: String, value: String) {
        db.settingDao().setSetting(LumaSettingEntity(key, value))
    }
    suspend fun getSetting(key: String): String? {
        return db.settingDao().getSetting(key)?.value
    }

    // Notifications
    val notifications: Flow<List<LumaNotificationEntity>> = db.notificationDao().getAllNotifications()
    suspend fun addNotification(title: String, message: String, appName: String) {
        db.notificationDao().insertNotification(
            LumaNotificationEntity(title = title, message = message, appName = appName)
        )
    }
    suspend fun deleteNotification(id: Int) {
        db.notificationDao().deleteNotificationById(id)
    }
    suspend fun clearNotifications() {
        db.notificationDao().clearAllNotifications()
    }
}
