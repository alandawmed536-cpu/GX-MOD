package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val CyberDarkColorScheme = darkColorScheme(
    primary = LumaCyberPrimary,
    onPrimary = Color.Black,
    secondary = LumaCyberSecondary,
    onSecondary = Color.White,
    tertiary = LumaCyberAccent,
    background = LumaCyberBackground,
    onBackground = LumaCyberOnBackground,
    surface = LumaCyberSurface,
    onSurface = Color.White,
    surfaceVariant = LumaCyberSurfaceVariant
)

private val LightColorScheme = lightColorScheme(
    primary = LumaLightPrimary,
    onPrimary = Color.White,
    secondary = LumaLightSecondary,
    onSecondary = Color.White,
    tertiary = LumaLightAccent,
    background = LumaLightBackground,
    onBackground = Color(0xFF0F172A),
    surface = LumaLightSurface,
    onSurface = Color(0xFF0F172A)
)

private val NeonMatrixColorScheme = darkColorScheme(
    primary = LumaNeonPrimary,
    onPrimary = Color.Black,
    secondary = LumaNeonSecondary,
    onSecondary = Color.Black,
    tertiary = LumaNeonAccent,
    background = LumaNeonBackground,
    onBackground = Color(0xFFDCFCE7),
    surface = LumaNeonSurface,
    onSurface = Color(0xFFDCFCE7)
)

@Composable
fun LumaTheme(
    themeMode: String = "DARK", // "DARK", "LIGHT", "NEON"
    content: @Composable () -> Unit
) {
    val colorScheme = when (themeMode) {
        "LIGHT" -> LightColorScheme
        "NEON" -> NeonMatrixColorScheme
        else -> CyberDarkColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
